<?php
require_once __DIR__ . "/../dbconnect.php";

if (!isset($pdo)) die("PDO missing");

echo "<h2>TEST LOG – RELEASE YEAR FIELD</h2><hr>";

function validateReleaseYear($value) {
    // Test log rules:
    // NULL = REJECT
    if (is_null($value)) return false;

    // Must be numeric
    if (!is_numeric($value)) return false;

    $year = intval($value);

    // Valid range 1900–2025
    if ($year < 1900) return false;
    if ($year > 2025) return false;

    return true;
}

function logYearTest($label, $value, $pdo) {
    $valid = validateReleaseYear($value);

    try {
        if (!$valid) throw new Exception("Simulated fail");

        $stmt = $pdo->prepare("
            INSERT INTO movies (user_id, title, release_year, poster, genre, poster_url, watched_status)
            VALUES (14, 'TestMovie', ?, NULL, 'TestGenre', NULL, 0)
        ");
        $stmt->execute([$value]);

        echo "<b>$label ($value):</b> <span style='color:green'>ACCEPTED</span><br>";

    } catch (Exception $e) {
        echo "<b>$label (" . (is_null($value) ? 'NULL' : $value) . "):</b> 
        <span style='color:red'>REJECTED</span><br>";
    }
}

// Test cases from your test log
logYearTest("Extreme Min", null, $pdo);
logYearTest("Min -1", 1899, $pdo);
logYearTest("Min Boundary", 1900, $pdo);
logYearTest("Min +1", 1901, $pdo);
logYearTest("Max -1", 2024, $pdo);
logYearTest("Max Boundary", 2025, $pdo);
logYearTest("Max +1", 2026, $pdo);
logYearTest("Mid", 2000, $pdo);
logYearTest("Extreme Max", 3000, $pdo);
logYearTest("Invalid datatype", "Twenty Twenty-Five", $pdo);
logYearTest("Negative year", -2025, $pdo);

echo "<hr><p>Release year test completed.</p>";
?>


