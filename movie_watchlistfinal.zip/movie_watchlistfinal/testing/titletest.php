<?php
require_once __DIR__ . "/../dbconnect.php";

if (!isset($pdo)) die("PDO missing");

echo "<h2>TEST LOG – TITLE FIELD</h2><hr>";

function validateTitle($value) {
    // Simulate validation like your system does
    if ($value === "") return false; // empty not allowed
    if (strlen($value) > 200) return false; // longer than db column
    return true;
}

function logTest($label, $value, $pdo) {
    $isValid = validateTitle($value);

    try {
        if (!$isValid) {
            throw new Exception("Simulated validation failure");
        }

        $stmt = $pdo->prepare("
            INSERT INTO movies 
            (user_id, title, release_year, poster, genre, poster_url, watched_status)
            VALUES (14, ?, 2024, NULL, 'TestGenre', NULL, 0)
        ");

        $stmt->execute([$value]);

        echo "<b>$label:</b> <span style='color:green'>ACCEPTED</span><br>";

    } catch (Exception $e) {
        echo "<b>$label:</b> <span style='color:red'>REJECTED</span><br>";
    }
}

logTest("Extreme Min (empty)", "", $pdo);
logTest("Min (1 char)", "A", $pdo);
logTest("Min+1", "AB", $pdo);
logTest("Max-1 (199 chars)", str_repeat("A", 199), $pdo);
logTest("Max (200 chars)", str_repeat("A", 200), $pdo);
logTest("Max+1 (201 chars)", str_repeat("A", 201), $pdo);
logTest("Mid", "Avatar", $pdo);
logTest("Extreme Max (300 chars)", str_repeat("A", 300), $pdo);
logTest("Invalid datatype (int)", "12345", $pdo);
logTest("SQL Injection attempt", "Movie'; DROP TABLE--", $pdo);

echo "<hr><p>Title test completed.</p>";
?>




