<?php
require_once __DIR__ . "/../dbconnect.php";

if (!isset($pdo)) die("PDO missing");

echo "<h2>TEST LOG – GENRE FIELD</h2><hr>";

function validateGenre($value) {
    if ($value === "") return false;        // empty not allowed
    if (strlen($value) > 100) return false; // max length
    if (ctype_digit($value)) return false;  // pure numbers rejected
    return true;
}

function logGenreTest($label, $value, $pdo) {
    $valid = validateGenre($value);

    try {
        if (!$valid) throw new Exception("Simulated fail");

        $stmt = $pdo->prepare("
            INSERT INTO movies 
            (user_id, title, release_year, poster, genre, poster_url, watched_status)
            VALUES (14, 'TestMovie', 2024, NULL, ?, NULL, 0)
        ");
        $stmt->execute([$value]);

        echo "<b>$label:</b> <span style='color:green'>ACCEPTED</span><br>";

    } catch (Exception $e) {
        echo "<b>$label:</b> <span style='color:red'>REJECTED</span><br>";
    }
}

// Test cases from your test log
logGenreTest("Extreme Min (empty)", "", $pdo);
logGenreTest("Min boundary (1 char)", "A", $pdo);
logGenreTest("Min +1 (2 chars)", "Ac", $pdo);
logGenreTest("Max -1 (99 chars)", str_repeat("A", 99), $pdo);
logGenreTest("Max boundary (100 chars)", str_repeat("A", 100), $pdo);
logGenreTest("Max +1 (101 chars)", str_repeat("A", 101), $pdo);
logGenreTest("Mid value", "Action, Drama", $pdo);
logGenreTest("Extreme Max (150 chars)", str_repeat("A", 150), $pdo);
logGenreTest("Invalid datatype (123)", "123", $pdo);
logGenreTest("SQL Injection attempt", "Genre'; DROP TABLE--", $pdo);

echo "<hr><p>Genre test completed.</p>";
?>

