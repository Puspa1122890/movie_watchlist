<?php
require_once __DIR__ . "/../dbconnect.php";

if (!isset($pdo)) die("PDO missing");

echo "<h2>TEST LOG – WATCHED STATUS FIELD</h2><hr>";

function validateWatchedStatus($value) {
    // Only valid: 0 or 1
    if ($value === 0 || $value === 1 || $value === "0" || $value === "1") {
        return true;
    }
    return false;
}

function logStatusTest($label, $value, $pdo) {
    $valid = validateWatchedStatus($value);

    try {
        if (!$valid) throw new Exception("Simulated fail");

        $stmt = $pdo->prepare("
            INSERT INTO movies 
            (user_id, title, release_year, poster, genre, poster_url, watched_status)
            VALUES (14, 'TestMovie', 2024, NULL, 'TestGenre', NULL, ?)
        ");
        $stmt->execute([$value]);

        echo "<b>$label ($value):</b> <span style='color:green'>ACCEPTED</span><br>";

    } catch (Exception $e) {
        echo "<b>$label (" . var_export($value, true) . "):</b> <span style='color:red'>REJECTED</span><br>";
    }
}

// Test cases based on your logs
logStatusTest("NULL", null, $pdo);
logStatusTest("Valid 0", 0, $pdo);
logStatusTest("Valid 1", 1, $pdo);
logStatusTest("Invalid 2", 2, $pdo);
logStatusTest("Extreme Max 255", 255, $pdo);
logStatusTest("String 'true'", "true", $pdo);
logStatusTest("Empty string", "", $pdo);
logStatusTest("Random string", "abc", $pdo);

echo "<hr><p>Watched status test completed.</p>";
?>
